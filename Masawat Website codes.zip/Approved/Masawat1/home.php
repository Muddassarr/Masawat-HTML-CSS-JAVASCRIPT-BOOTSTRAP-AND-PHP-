<?php

session_start();
if(isset($_SESSION['user']))
{
	header('location:login.php');
}
?>
<html>

<body>
<a href="logout.php">logout</a>
<h1>welcome</h1>
</body>
</html>